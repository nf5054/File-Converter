@echo off
cd /d "%~dp0OmniConvert"
start "" "%~dp0OmniConvert\OmniConvert.exe"
