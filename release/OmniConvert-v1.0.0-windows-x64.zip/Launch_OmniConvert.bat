@echo off
start "" "%~dp0OmniConvert\OmniConvert.exe"
